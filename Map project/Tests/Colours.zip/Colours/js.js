var Places = [
                [document.getElementById("auckland"), 400, "AKL"],
                [document.getElementById("bay_of_plenty"), 235, "TRG"],
                [document.getElementById("canterbury"), 250, "CHC"],
                [document.getElementById("chatham_islands_territory"), 278],
                [document.getElementById("gisborne"), 278, "GIS"],
                [document.getElementById("hawkes_bay"), 170, "NPE"],
                [document.getElementById("marlborough"), 150, "BHE"],
                [document.getElementById("manawatu_wanganui"), 150, "PMR"],
                [document.getElementById("nelson"), 100, "NSN"],
                [document.getElementById("northland"), 278, "WRE"],
                [document.getElementById("otago"), 300, "DUD"],
                [document.getElementById("southland"), 350, "IVC"],
                [document.getElementById("tasman"), 100, "NSN"],
                [document.getElementById("taranaki"), 220, "NPL"],
                [document.getElementById("waikato"), 250, "HLZ"],
                [document.getElementById("wellington"), 0, "WLG"],
                [document.getElementById("west_coast"), 200, "HKK"],
                
            ];


var APIdata

Places.forEach(function(place) {
    place[0].addEventListener('click', function() {
        this.style.fill='green';
        var currentPlace = place[2]
        console.log(makeRequest(currentPlace, "AKL"));
        
        
        

    });
});

function makeRequest(originCode, desCode) {
    var data = null;

    var xhr = new XMLHttpRequest();
    xhr.withCredentials = true;


    xhr.open("GET", "https://api.airnz.io/api/v1/cached-flight-prices?countryCode=NZ&originCityCode="+ originCode+"&destinationCityCode="+desCode+"&fromDate=2018-11-26&toDate=2018-11-26");
    xhr.setRequestHeader("Authorization", "Bearer eyJraWQiOiJhaXJuei1nZW4tand0IiwidHlwIjoiSldUIiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJBaXIgTmV3IFplYWxhbmQtc3VtbWVyLW9mLXRlY2giLCJhdWQiOiJBaXJOWlByb2QiLCJpc3MiOiJBaXJOWi1EaWdpdGFsU2hhcmVkUGxhdGZvcm1zIiwic2NvcGVzIjoiZmxpZ2h0X29mZmVyczpwPS9hcGkvdjEvZmxpZ2h0LW9mZmVycyBsb2NhdGlvbiBjYWNoZWRfZmxpZ2h0X3ByaWNlcyIsImV4cCI6MTU0MjI3OTYwMH0.eqXGrIGPl9Mv_LmZ5Nkncd6fNEWqn5SE3mHMMzGESfuS56mm-9B70trVO6V9uvmu1-jJMiZs9NWln5I90BY064XALiXsepDiU6iS01lmX81ihudgPP2a5kbkPuxTsvszJGCPHkWXyDL01t9rRsxnUQA-4DcZPdWWcUQFDuN9EoI_IQv3xawZpN2lWiITQE9WI3C4IhLIHTPMsP-Zl3Wx2Q6RMb2JUBSjz_2yqma0gpBS53xJH8vef3d1LXR4FN4KVBF_oz8yD86lJn8bXhsaDKwE8EiqRywtOOZ-Q0KX15oV6dQxF5Y_ojnTusu_pttWEEMWr0ioUtSfi_clhnR6rA");
    xhr.setRequestHeader("Cache-Control", "no-cache");
    xhr.setRequestHeader("Postman-Token", "25cb5c96-7707-4db9-a18d-51b8ca5bd512");

    xhr.send(data);
    
    xhr.addEventListener("readystatechange", function () {
              if (this.readyState === 4) {
                console.log(this.responseText);
                APIdata = JSON.parse(this.responseText)
                return APIdata.prices[0].adultPriceIncludingTax
              } 
            });
}
